<?php
// Menggunakan kode dari database.php
require 'database.php';

ini_set('date.timezone', 'Asia/Jakarta');

$now = new DateTime();

$datenow = $now->format("Y-m-d H:i:s");
var_dump($_SERVER["REQUEST_METHOD"]);

//Mengambil data dari Web Server ESP 
$suhu = $_POST['temperature'];
$humid = $_POST['humidity'];
$ldr = $_POST['ldr'];

//Masukin data ke MySQL
$sql = "INSERT INTO monitoring VALUES (NULL,
     			'$suhu',
				'$humid',
				'$ldr',
                    '$datenow')";

// Cek sukses tidak
if ($connect->query($sql) === TRUE) {
     echo json_encode("Ok");
} else {
     echo "Error: " . $sql . "<br>" . $connect->error;
}

$connect->close();
